
/**
 * A class that represents an order screen in a restaurant.
 *
 * @author Sena Yevenyo
 * @version September 29, 2019
 */
public class OrderScreen
{
    // instance variables
    
    private boolean available;
    private int id;
    public static final float MAINTENANCE_COST = (float) 0.0115;
    /**
     * Constructor for objects of class OrderScreen
     */
    public OrderScreen(int id)
    {
        this.id = id;
        available = true;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
}
