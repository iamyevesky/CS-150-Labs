import java .awt  .Canvas;
import java .awt  .Graphics;
import java .awt  .Color;
import javax.swing.JFrame;
import java.util.*;
import java.io.*;
/**
 * A class that offers template for the instantiation of Dwarf miners.
 *
 * @author Sena Yevenyo
 * @version October 21, 2019
 */
public class Dwarf implements Comparable<Dwarf>
{
    // instance variables - replace the example below with your own
    /**
     * Maximum amount of gold value a Dwarf object can carry
     */
    private static final int CARRY_MAX = 30;
    private static Queue <Dwarf> dwarfQueue = new PriorityQueue<Dwarf>(1);
    private static Queue <Dwarf> nDwarfQueue = new PriorityQueue<Dwarf>(1);
    private static int numOfDwarfs = 10;
    private static Map map;
    private static String[] states = {"stay","mine","move","dig"};
    private static Random random = new Random();
    private static PrintWriter writer = null;
    
    private int carry;
    private String state;
    private int vectorX;
    private int vectorY;
    private MapNode currPos;
    private MapNode top = null;
    private MapNode down = null;
    private MapNode left = null;
    private MapNode right = null;
    private ArrayList<MapNode> edgeNodes = new ArrayList<MapNode>(4);
    private Color dwarfColor = new Color(255,255,255);
    private int id;
    private int diff;
    private boolean delete;
  
    
    public static void setNumOfDwarfs(int value){
        numOfDwarfs = value;
    }
    
    public static void setMap(Map value){
        map = value;
    }
    
    public static void setWriter(PrintWriter writeObject){
        writer = writeObject;
    }
    
    public static void initDwarfs(){
        writer.println("+++Adding dwarfs to simulation+++");
        writer.println();
        for(int i=0;i<numOfDwarfs;i++){
            Dwarf newDwarf = new Dwarf(i, i, map.get(0,0));
            dwarfQueue.add(newDwarf);
            writer.println("Dwarf "+newDwarf.getID()+" has been added to simulation!");
        }
        writer.println("===================================================");
        writer.println();
    }
    
    public static void goDwarfs(){
        Dwarf dwarf = dwarfQueue.poll();
        writer.println("Dwarf "+dwarf.getID()+" about to go!");
        dwarf.go();
        
        writer.println();
        if(!dwarf.isDeleted()){
            if(dwarf.getDiff()==0) dwarf.setDiff(numOfDwarfs-1);
            else dwarf.setDiff(numOfDwarfs-dwarf.getDiff()-1);
            nDwarfQueue.add(dwarf);
        }
        
        if(dwarfQueue.peek()==null){
            dwarfQueue = nDwarfQueue;
            nDwarfQueue = null;
            nDwarfQueue = new PriorityQueue<Dwarf>(1);
            writer.println();
            writer.println("All dwarfs completed task!");
            writer.println("===================================================");
            writer.println();
        }
    }
    
    public static void paintDwarfs(Graphics g){
        for(Dwarf dwarf:dwarfQueue){
            writer.println("Dwarf "+dwarf.getID()+" about to be painted!");
            dwarf.paint(g);
        }
    }
    
    /**
     * Constructor for objects of class Dwarf
     */
    public Dwarf(int id, int diff, MapNode node)
    {
        // initialise instance variables
        carry = 0;
        currPos = node;
        this.id = id;
        this.diff = diff;
        delete = false;
        state = states[0];
        edgeNodes.add(right);
        edgeNodes.add(down);
        edgeNodes.add(left);
        edgeNodes.add(top);
        updatePos();
    }
    
    public void go()
    {
        //writer.println("Dwarf "+this.getID()+" current position = "+currPos.toString());
        if(currPos.getFeature().compareTo("gold")==0){ //State Mine
            //mine
            writer.println("Dwarf "+this.getID()+" digs gold!");
            this.carry = this.carry + currPos.digGold();
            state = "mine";
        }
        else if(currPos.getFeature().compareTo("water")==0||currPos.getFeature().compareTo("lava")==0||currPos.getFeature().compareTo("pit")==0){
            this.delete = true;
            writer.println("Dwarf "+this.getID()+" falls into "+currPos.getFeature()+" and dies!");
        }
        else{
            for(int i=0;i<edgeNodes.size();i++){
                if(edgeNodes.get(i)!=null){
                    MapNode nextNode = edgeNodes.get(i);
                    if(nextNode.getFeature().compareTo("tunnel")==0){
                        //writer.println("Dwarf "+this.getID()+" moves into "+currPos.getFeature()+" from "+currPos.toString()+" to "+nextNode.getFeature()+".");
                        currPos = nextNode;
                        updatePos();
                        state = "move";
                        break;
                    }
                }else break;
            }
            
            for(int i=0;i<edgeNodes.size();i++){
                if(edgeNodes.get(i)!=null){
                    MapNode nextNode = edgeNodes.get(i);
                    if(nextNode.getFeature().compareTo("pit")==0){
                        writer.println("Dwarf "+this.getID()+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.getFeature()+".");
                        currPos = nextNode;
                        currPos.buildBridge();
                        updatePos();
                        state = "build";
                        break;
                    }
                }else break;
            }
            
            for(int i=0;i<edgeNodes.size();i++){
                if(edgeNodes.get(i)!=null){
                    MapNode nextNode = edgeNodes.get(i);
                    if(nextNode.getFeature().compareTo("rock")==0){
                        writer.println("Dwarf "+this.getID()+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.getFeature()+".");
                        currPos = nextNode;
                        currPos.dig();
                        updatePos();
                        state = "dig";
                        break;
                    }
                }else break;
            }
        }
    }
    
    /**
     * Paints visualization of Dwarf object on canvas
     */
    public void paint(Graphics g) {
        g.setColor(dwarfColor);
        g.fillOval(vectorX-5,vectorY-5,10,10);
    }
    
    private void updatePos(){
        vectorX = 30*currPos.getX()+15;
        vectorY = 30*currPos.getY()+15;
        
        if(currPos.getY()>0){
            edgeNodes.set(3,map.get(currPos.getX(),currPos.getY()-1));//top
        }
        else edgeNodes.set(3,null);//top
        
        if(currPos.getX()>0){
            edgeNodes.set(2,map.get(currPos.getX()-1,currPos.getY()));//left
        }
        else edgeNodes.set(2,null);//left
        
        if(currPos.getX()<map.getWidth()-1){
            edgeNodes.set(0,map.get(currPos.getX()+1,currPos.getY()));//right
        }
        else edgeNodes.set(0,null);//right
        
        if(currPos.getY()<map.getHeight()-1){
            edgeNodes.set(1,map.get(currPos.getX(),currPos.getY()+1));//down
        }
        else edgeNodes.set(1,null);//down
    }
    
    public int getDiff(){
        return diff;
    }
    
    public int getID(){
        return id;
    }
    
    public void setDiff(int value){
        diff = value;
    }
    
    public boolean isDeleted(){
        return delete;
    }
    
    public int getCarry(){
        return carry;
    }
    
    public String getPos(){
        return currPos.toString();
    }
    
    @Override
    public int compareTo(Dwarf object){
        return (int) (diff - object.getDiff());
    }
}
