import java .awt  .Canvas;
import java .awt  .Graphics;
import java .awt  .Color;
import javax.swing.JFrame;
import java.util.*;
import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
 * The test class DwarfTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class DwarfTest
{
    Map map = new Map(30,30);
    Dwarf dwarf0, dwarf1, dwarf2, dwarf3, dwarf4;
    MapNode pitNode = new MapNode(4,4,4);
    MapNode goldNode = new MapNode(6,6,2);
    
    /**
     * Default constructor for test class DwarfTest
     */
    public DwarfTest()
    {
        Dwarf.setMap(map);
        dwarf0 = new Dwarf(0,0,map.get(0,0));
        dwarf1 = new Dwarf(1,2,map.get(0,0));
        dwarf2 = new Dwarf(2,5,map.get(0,0));
        dwarf3 = new Dwarf(1,1,pitNode);
        dwarf4 = new Dwarf(1,1,goldNode);
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @Before
    public void setUp()
    {
    }
    
    @Test
    public void testGetDiff(){
        assertEquals(0,dwarf0.getDiff());
    }
    
    @Test
    public void testGetDiff1(){
        assertEquals(5,dwarf2.getDiff());
    }
    
    @Test
    public void testGetID(){
        assertEquals(0,dwarf0.getID());
    }
    
    @Test
    public void testGetID1(){
        assertEquals(2,dwarf2.getID());
    }
    
    @Test
    public void testSetDiff(){
        dwarf0.setDiff(13);
        assertEquals(13,dwarf0.getDiff());
    }
    
    @Test
    public void testIsDeleted0(){
        assertEquals(false,dwarf0.isDeleted());
    }
    
    @Test
    public void testIsDeleted1(){
        pitNode.dig();
        dwarf3.go();
        assertEquals(true, dwarf3.isDeleted());
    }
    
    @Test
    public void testDigGold(){
        goldNode.dig();
        dwarf4.go();
        assertEquals(1, dwarf4.getCarry());
    }
    
    @Test
    public void testGo0(){
        dwarf0.go();
        assertEquals("(1,0)",dwarf0.getPos());
    }
    
    @Test
    public void testGo1(){
        dwarf1.go();
        assertEquals("(1,0)",dwarf1.getPos());
    }
    
    @Test
    public void testGo2(){
        dwarf2.go();
        assertEquals("(1,0)",dwarf2.getPos());
    }
    
    @Test
    public void testCompareTo(){
        assertEquals(-5,dwarf0.compareTo(dwarf2));
    }
    
    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @After
    public void tearDown()
    {
    }
}
