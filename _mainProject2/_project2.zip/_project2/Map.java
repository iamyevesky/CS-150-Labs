import java .awt  .Canvas;
import java .awt  .Graphics;
import java .awt  .Color;
import javax.swing.JFrame;
import java.util.*;
/**
 * A class that represents the map of the game.
 *
 * @author Sena Yevenyo
 * @version October 21 2019 
 */
public class Map
{
    // instance variables - replace the example below with your own
    private int squareSize = 25;
    private int gridSize = 30;
    private int parkSizeX, parkSizeY, mapWidth, mapHeight;
    private ArrayList<ArrayList<MapNode>> mapArray;
    private Random random = new Random();
    /**
     * Constructor for objects of class Map
     */
    public Map()
    {
        // initialise instance variables
        mapWidth = 30;
        mapHeight = 30;
        parkSizeX = mapWidth*gridSize;
        parkSizeY = mapHeight*gridSize;
        mapArray = new ArrayList<ArrayList<MapNode>>();
        
        for(int i=0;i<mapWidth;i++){
            mapArray.add(new ArrayList<MapNode>());
            for(int j=0;j<mapHeight;j++){
                mapArray.get(i).add(new MapNode(i,j,1));
            }
        }
    }
    
    /**
     * Constructor for objects of class Map
     */
    public Map(int x, int y)
    {
        // initialise instance variables
        mapWidth = x;
        mapHeight = y;
        parkSizeX = mapWidth*gridSize;
        parkSizeY = mapHeight*gridSize;
        mapArray = new ArrayList<ArrayList<MapNode>>();
        
        for(int i=0;i<mapWidth;i++){
            mapArray.add(new ArrayList<MapNode>());
            for(int j=0;j<mapHeight;j++){
                mapArray.get(i).add(new MapNode(i,j,1));
            }
        }
    }
    
    /**
     * Paints visualization of Map object on canvas
     */
    public void paint(Graphics g) {
        for(int x = 0; x < mapWidth; x++){
            for(int y = 0; y < mapHeight; y++){
            g.setColor(mapArray.get(x).get(y).getColor());
            g.fillRect((x*gridSize)+((gridSize-squareSize)/2),
               (y*gridSize)+((gridSize-squareSize)/2),
                squareSize,
                squareSize);
            }
        }
    }
    
    public MapNode get(int x, int y){
        return mapArray.get(x).get(y);
    }
    
    public int getWidth(){
        return mapWidth;
    }
    
    public int getHeight(){
        return mapHeight;
    }
}