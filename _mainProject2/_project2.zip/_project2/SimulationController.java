import java .awt  .Canvas;
import java .awt  .Graphics;
import java .awt  .Color;
import javax.swing.JFrame;
import java.util.concurrent.TimeUnit;
import java.util.*;
import java.io.*;
/**
 * Class that controls the game and simulation.
 *
 * @author Sena Yevenyo
 * @version October 21, 2019
 */
public class SimulationController extends Canvas
{
    // instance variables - replace the example below with your own
    public static int mapWidth;
    public static int mapHeight;
    private JFrame frame;
    private int squareSize = 25;
    private int gridSize = 30;
    private int parkSizeX, parkSizeY;
    private int numOfDwarfs = 20;
    private Map map;
    String logFilename = null;
    PrintWriter writer = null;
    File logData = null;
    /**
     * Main method of the program.
     * 
     * Runs a for loop simulating the GlobalClock.tick() in the final program.
     */
    public static void main(String args[]){
        String fileName = null;
        SimulationController simul = null;
        System.out.println(args[0]);
        System.out.println(args[1]);
        System.out.println(args[2]);
        // System.out.println(args[3])
        try{
            fileName = args[0]+".txt";
            simul = new SimulationController(fileName,Integer.parseInt(args[1]),Integer.parseInt(args[2]));
        }catch(Exception e){
            System.err.println(e);
        }
        
        simul.start();
    }

    /**
     * Constructor for objects of class SimulationController
     */
    public SimulationController(String filename)
    {
        // initialise instance variables
        logFilename = "log"+filename;
        frame = new JFrame("Gold mine");
        mapWidth = 30;
        mapHeight = 30;
        parkSizeX = mapWidth*gridSize;
        parkSizeY = mapHeight*gridSize;
        this.setSize(parkSizeX, parkSizeY);
        map = new Map(mapWidth,mapHeight);

        try{
            logData = new File(logFilename);
            writer = new PrintWriter(logData);
            Dwarf.setWriter(writer);
        }catch(Exception e){
            System.err.println(e);
        }

        Dwarf.setNumOfDwarfs(numOfDwarfs);
        Dwarf.setMap(map);
        Dwarf.initDwarfs();

        frame.add(this);
        frame.setSize(parkSizeX,parkSizeY);
        frame.setVisible(true);
    }

    public SimulationController(String filename, int x, int y){
        logFilename = "log"+filename;
        frame = new JFrame("Gold mine");
        mapWidth = x;
        mapHeight = y;
        parkSizeX = mapWidth*gridSize;
        parkSizeY = mapHeight*gridSize;
        this.setSize(parkSizeX, parkSizeY);
        map = new Map(mapWidth,mapHeight);

        try{
            logData = new File(logFilename);
            writer = new PrintWriter(logData);
            Dwarf.setWriter(writer);
        }catch(Exception e){
            System.err.println(e);
        }

        Dwarf.setNumOfDwarfs(numOfDwarfs);
        Dwarf.setMap(map);
        Dwarf.initDwarfs();

        frame.add(this);
        frame.setSize(parkSizeX,parkSizeY);
        frame.setVisible(true);
    }

    public void start(){
        writer.println("+++Starting simulation+++");
        writer.println("+++Dwarfs about to start!+++");
        writer.println();
        writer.println("===================================================");
        writer.println();
        while(GlobalClock.time()<60){
            Dwarf.goDwarfs();
            this.repaint();
            try{
                TimeUnit.SECONDS.sleep(1);
            }catch(InterruptedException e){
                System.out.println(e);
            }
        }

        writer.println();
        writer.println("Simulation completed");
        writer.println("===================================================");
        writer.println();
        System.out.println("Simulation completed");
        writer.close();
    }

    public void paint(Graphics g){
        map.paint(g);
        Dwarf.paintDwarfs(g);
    }
}
