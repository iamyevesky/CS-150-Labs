    import java .awt  .Canvas;
    import java .awt  .Graphics;
    import java .awt  .Color;
    import javax.swing.JFrame;
    import java.util.*;
    import java.io.*;
    /**
     * A class that offers template for the instantiation of Dwarf miners.
     *
     * @author Sena Yevenyo
     * @version October 21, 2019
     */
    public class Dwarf implements Comparable<Dwarf>
    {
        // instance variables - replace the example below with your own
        /**
         * Maximum amount of gold value a Dwarf object can carry
         */
        private static final int CARRY_MAX = 30;
        private static Queue <Dwarf> dwarfQueue = new PriorityQueue<Dwarf>(1);
        private static Queue <Dwarf> nDwarfQueue = new PriorityQueue<Dwarf>(1);
        private static int numOfDwarfsSearchers;
        private static int numOfDwarfsDiggers;
        private static int numOfDwarfsMinerBuilders;
        private static int numOfDwarfsSuperMiners;
        private static int numOfDwarfsUltimateMiners;
        private static int totalMiners;
        
        private static Map map;
        private static ArrayList<Integer> diffArray = new ArrayList<Integer>(1);
        private static Random random = new Random();
        private static PrintWriter logWriter = null;
        private static PrintWriter dataWriter = null;
        private static Color dwarfColor = new Color(255,255,255);
        
        private static int totalGold = 0;
        private static int diedByLava = 0;
        private static int diedByPit = 0;
        private static int diedByRiver = 0;
        private static ArrayList<int []> dwarfData = new ArrayList<int[]>(1); 
        
        private int carry;
        private String state;
        private int vectorX;
        private int vectorY;
        private MapNode currPos;
        private ArrayList<MapNode> edgeNodes = new ArrayList<MapNode>(4);
        private Stack<MapNode> prevLoc = new Stack();
        
        private int id;
        private int diff;
        private boolean delete;
        private int totalGoldMined;
        private int deathInt;
        private Color color;
        private String type;
        /**
         * Sets the number of dwarfs for a simulation
         * 
         * @param int numberOfSearchers for the simulation
         * @param int numberOfDiggers for the simulation
         * @param int numberOfMinerBuilders for the simulation
         * @param int numberOfSuperMiners for the simulation
         * @param int numberOfUltimateMiners for the simulation
         */
        public static void setNumOfDwarfs(int numOfSearchers, int numOfDiggers, int numOfMinerBuilders, int numOfSuperMiners, int numOfUltimateMiners){
            numOfDwarfsSearchers = numOfSearchers;
            numOfDwarfsDiggers = numOfDiggers;
            numOfDwarfsMinerBuilders = numOfMinerBuilders;
            numOfDwarfsSuperMiners = numOfSuperMiners;
            numOfDwarfsUltimateMiners = numOfUltimateMiners;
            totalMiners = numOfDwarfsSearchers + numOfDwarfsDiggers + numOfDwarfsSuperMiners + numOfDwarfsMinerBuilders + numOfDwarfsUltimateMiners;
            dwarfData = new ArrayList<int[]>(totalMiners);
            for(int i=0;i<totalMiners;i++){
                int [] data = new int[2];
                dwarfData.add(data);
            }
        }
        
        /**
         * Sets the map for a simulation
         * 
         * @param map for the simulation
         */
        public static void setMap(Map value){
            map = value;
        }
        
        /**
         * Sets the PrintWriter object of simulation, into which log data is written
         * 
         * @param PrintWriter for log data
         */
        public static void setWriter(PrintWriter logWriteObject, PrintWriter dataWriteObject){
            logWriter = logWriteObject;
            dataWriter = dataWriteObject;
        }
        
        /**
         * Initializes global Dwarf objects in Dwarf class for class-level simulation. 
         *  
         */
        public static void initDwarfs(){
            printToWriter("+++Adding dwarfs to simulation+++");
            printToWriter();
            for(int i=0;i<totalMiners;i++){
                Dwarf newDwarf = null;
                if(i<numOfDwarfsSearchers)  newDwarf = new Dwarf(i, i, map.get(0,0),1);
                else if(i<numOfDwarfsDiggers+numOfDwarfsSearchers) newDwarf = new Dwarf(i, i, map.get(0,0),2);
                else if(i<numOfDwarfsDiggers+numOfDwarfsSearchers+numOfDwarfsMinerBuilders) newDwarf = new Dwarf(i, i, map.get(0,0),3);
                else if(i<numOfDwarfsDiggers+numOfDwarfsSearchers+numOfDwarfsMinerBuilders+numOfDwarfsSuperMiners) newDwarf = new Dwarf(i, i, map.get(0,0),4);
                else if(i<totalMiners) newDwarf = new Dwarf(i, i, map.get(0,0),5);
                dwarfQueue.add(newDwarf);
                diffArray.add(i);
                printToWriter("Dwarf "+newDwarf.getID()+" has been added to simulation!");
            }
            
            printToWriter("===================================================");
            printToWriter();
        }
        
        /**
         * Enables next-Dwarf-in-queue to crawl over map and take actions.
         * 
         * @param canvas input to update movement of Dwarfs.
         */
        public static void goDwarfs(Canvas canvas){
            Dwarf dwarf = dwarfQueue.poll();
            printToWriter("Dwarf "+dwarf.getID()+" about to go!");
            dwarf.go();
            int initDiff = dwarf.getDiff();
            diffArray.remove(Integer.valueOf(initDiff));
            printToWriter();
            if(!dwarf.isDeleted()){
                dwarf.setDiff(diffArray.get(random.nextInt(diffArray.size())));
                nDwarfQueue.add(dwarf);
                diffArray.add(initDiff);
            }else{//Dwarf is dead
                dwarfData.set(dwarf.getID(),dwarf.getData());
            }
            
            if(canvas!=null) canvas.repaint();
            
            if(dwarfQueue.peek()==null){
                dwarfQueue = nDwarfQueue;
                nDwarfQueue = null;
                nDwarfQueue = new PriorityQueue<Dwarf>(1);
                printToWriter();
                printToWriter("All dwarfs completed task!");
                printToWriter("===================================================");
                printToWriter();
            }
        }
        
        /**
         * Prints data of individual dwarf into a .csv file.
         * 
         */
        public static void printDwarfData(){
            printToDataWriter("ID, TotalGoldMined, Death");
            for(int i=0;i<dwarfData.size();i++){
                String death = "Did not die";
                int[] data = dwarfData.get(i);
                if(data[1]==1){
                    death = "Lava";
                }else if(data[1]==2){
                    death = "Pit";
                }else if(data[1]==3){
                    death = "River";
                }
                printToDataWriter(i+", "+data[0]+", "+death);
            }
        }
        
        /**
         * Draws Dwarf objects on map canvas
         * 
         * @param Graphics object that draws Dwarf objects
         */
        public static void paintDwarfs(Graphics g){
            for(Dwarf dwarf:dwarfQueue){
                //printToWriter("Dwarf "+dwarf.getID()+" about to be painted!");
                dwarf.paint(g);
            }
            for(Dwarf dwarf:nDwarfQueue){
                //printToWriter("Dwarf "+dwarf.getID()+" about to be painted!");
                dwarf.paint(g);
            }
        }
        
        /**
         * Writes text into log files
         * 
         * @param text to be written into log file
         */
        private static void printToWriter(String text){
            if(logWriter!=null) {
                logWriter.println(text);
            }
        }
        
        /**
         * Writes empty line into log files
         * 
         */
        private static void printToWriter(){
            if(logWriter!=null){
                logWriter.println();
            }
        }
        
        /**
         * Writes text into data files
         * 
         * @param text to be written into data file
         */
        private static void printToDataWriter(String text){
            if(dataWriter!=null) {
                dataWriter.println(text);
            }
        }
        
        /**
         * Writes empty line into data files
         * 
         */
        private static void printToDataWriter(){
            if(dataWriter!=null){
                dataWriter.println();
            }
        }
        
        /**
         * Constructor for objects of class Dwarf
         */
        public Dwarf(int id, int diff, MapNode node, int type)
        {
            // initialise instance variables
            switch(type){
                //1 is for ground/tunnel
                case 1: color = new Color(0,0,255); this.type = "searcher";
                break;
                //2 is for gold
                case 2: color = new Color(255,0,0); this.type = "digger";
                break;
                //3 is for water
                case 3: color = new Color(0,255,0); this.type = "minerBuilder";
                break;
                //4 is for pit
                case 4: color = new Color(255,0,255); this.type = "superMiner";
                break;
                //5 is for lava
                case 5: color = new Color(255,255,0); this.type = "ultimateMiner";
                break;
                default: color = new Color(255,255,255); this.type = "error";
            }
            
            totalGoldMined = 0;
            deathInt = 0;
            currPos = node;
            prevLoc.push(currPos);
            currPos.addDwarf(this);
            this.id = id;
            this.diff = diff;
            state = "stay";
            delete = false;
            for(int i=0;i<4;i++) edgeNodes.add(null);
            updatePos();
        }
        
        /**
         * Determines the state of the Dwarf object and executes action based on state (Moore's Machine implementation)
         *
         *
         */
        public void go()
        {
            String currString = currPos.toString();
            printToWriter("Dwarf "+this.getID()+" current position = "+currPos.toString());
            MapNode nextNode = null;
            
            //River feature implementation
            if(currPos.getFeature().compareTo("water")==0){
                for(int i=0;i<3;i++){
                    MapNode link = currPos.getLink();
                    if(link!=null){
                        String feature = link.getFeature();
                        if(feature.compareTo("water")==0){
                            currPos = link;
                            updatePos();
                        }
                    }
                    else{
                        currPos = null;
                        break;
                    }
                }
            }
            
            //Determine state
            if(currPos == null) state = "die"; //flowed out of map
            else if(currPos.getFeature().compareTo("lava")==0||currPos.getFeature().compareTo("pit")==0) state = "die";
            else if(currPos.getFeature().compareTo("gold")==0) state = "mine";
            else if(edgeNodes.get(0)!=null && edgeNodes.get(0).getFeature().compareTo("rock")==0) {
                state = "digRight";
                nextNode = edgeNodes.get(0);
            }
            else if(edgeNodes.get(1)!=null && edgeNodes.get(1).getFeature().compareTo("rock")==0) {
                state = "digBottom";
                nextNode = edgeNodes.get(1);
            }
            else if(edgeNodes.get(2)!=null && edgeNodes.get(2).getFeature().compareTo("rock")==0) {
                state = "digLeft";
                nextNode = edgeNodes.get(2);
            }
            else if(edgeNodes.get(3)!=null && edgeNodes.get(3).getFeature().compareTo("rock")==0) {
                state = "digTop";
                nextNode = edgeNodes.get(3);
            }
            else if(edgeNodes.get(0)!=null && edgeNodes.get(0).getFeature().compareTo("pit")==0) {
                state = "buildRight";
                nextNode = edgeNodes.get(0);
            }
            else if(edgeNodes.get(1)!=null && edgeNodes.get(1).getFeature().compareTo("pit")==0) {
                state = "buildBottom";
                nextNode = edgeNodes.get(1);
            }
            else if(edgeNodes.get(2)!=null && edgeNodes.get(2).getFeature().compareTo("pit")==0) {
                state = "buildLeft";
                nextNode = edgeNodes.get(2);
            }
            else if(edgeNodes.get(3)!=null && edgeNodes.get(3).getFeature().compareTo("pit")==0) {
                state = "buildTop";
                nextNode = edgeNodes.get(3);
            }
            else if(edgeNodes.get(1)!=null && edgeNodes.get(1).getFeature().compareTo("tunnel")==0 && edgeNodes.get(1).beenPresent(this)==false) {
                state = "moveBottom";
                nextNode = edgeNodes.get(1);
            }
            else if(edgeNodes.get(0)!=null && edgeNodes.get(0).getFeature().compareTo("tunnel")==0 && edgeNodes.get(0).beenPresent(this)==false) {
                state = "moveRight";
                nextNode = edgeNodes.get(0);
            }
            else if(edgeNodes.get(2)!=null && edgeNodes.get(2).getFeature().compareTo("tunnel")==0 && edgeNodes.get(2).beenPresent(this)==false) {
                state = "moveLeft";
                nextNode = edgeNodes.get(2);
            }
            else if(edgeNodes.get(3)!=null && edgeNodes.get(3).getFeature().compareTo("tunnel")==0 && edgeNodes.get(3).beenPresent(this)==false) {
                state = "moveTop";
                nextNode = edgeNodes.get(3);
            }
            else {
                state = "stay";
            }
            
            //Determine output/action
            switch(state){
                case "mine": 
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs gold!");
                    this.totalGoldMined+= currPos.digGold();
                    totalGold++;
                    break;
                case "die":
                    this.delete = true;
                    if(currPos==null){
                        diedByRiver++;
                        deathInt = 1;
                    }
                    else if(currPos.getFeature().compareTo("lava")==0){
                        diedByLava++;
                        deathInt = 2;
                    }
                    else if(currPos.getFeature().compareTo("pit")==0){
                        diedByPit++;
                        deathInt = 3;
                    }
                    
                    if(currPos!=null){
                        printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" falls into "+currPos.getFeature()+" and dies!");
                    }
                    else{
                       printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" flows off the map by River at "+currString+" and dies!"); 
                    }
                    break;
                case "digRight":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "digBottom":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "digLeft":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "digTop":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "buildRight":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "buildBottom":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "buildLeft":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "buildTop":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "moveRight":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+"("+this.getType()+")"+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;    
                case "moveBottom":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;
                case "moveLeft":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;
                case "moveTop":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;
                default:
                    MapNode prevPos = prevLoc.pop();
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" treks back. Moves from current position "+currPos.toString()+" to previous position "+prevPos.toString()+".");
                    currPos = prevPos;
                    updatePos();
                    break;
            }
        }
        
        
        /**
         * Determines the state of the Dwarf object who is a searcher and executes action based on state (Moore's Machine implementation)
         *
         *
         */
        public void goSearchers()
        {
            String currString = currPos.toString();
            printToWriter("Dwarf "+this.getID()+" current position = "+currPos.toString());
            MapNode nextNode = null;
            
            //River feature implementation
            if(currPos.getFeature().compareTo("water")==0){
                //Delete previous locations to prevent teleporting when treking back
                while(!prevLoc.empty()){
                    prevLoc.pop();
                }
                
                for(int i=0;i<3;i++){
                    MapNode link = currPos.getLink();
                    if(link!=null){
                        String feature = link.getFeature();
                        if(feature.compareTo("water")==0){
                            currPos = link;
                            updatePos();
                        }
                    }
                    else{
                        currPos = null;
                        break;
                    }
                }
            }
            
            //Determine state
            if(currPos == null) state = "die"; //flowed out of map
            else if(currPos.getFeature().compareTo("lava")==0||currPos.getFeature().compareTo("pit")==0) state = "die";
            else if(currPos.getFeature().compareTo("gold")==0) state = "shout";
            else if(edgeNodes.get(0)!=null && edgeNodes.get(0).getFeature().compareTo("rock")==0) {
                state = "digRight";
                nextNode = edgeNodes.get(0);
            }
            else if(edgeNodes.get(1)!=null && edgeNodes.get(1).getFeature().compareTo("rock")==0) {
                state = "digBottom";
                nextNode = edgeNodes.get(1);
            }
            else if(edgeNodes.get(2)!=null && edgeNodes.get(2).getFeature().compareTo("rock")==0) {
                state = "digLeft";
                nextNode = edgeNodes.get(2);
            }
            else if(edgeNodes.get(3)!=null && edgeNodes.get(3).getFeature().compareTo("rock")==0) {
                state = "digTop";
                nextNode = edgeNodes.get(3);
            }
            else if(edgeNodes.get(0)!=null && edgeNodes.get(0).getFeature().compareTo("pit")==0) {
                state = "buildRight";
                nextNode = edgeNodes.get(0);
            }
            else if(edgeNodes.get(1)!=null && edgeNodes.get(1).getFeature().compareTo("pit")==0) {
                state = "buildBottom";
                nextNode = edgeNodes.get(1);
            }
            else if(edgeNodes.get(2)!=null && edgeNodes.get(2).getFeature().compareTo("pit")==0) {
                state = "buildLeft";
                nextNode = edgeNodes.get(2);
            }
            else if(edgeNodes.get(3)!=null && edgeNodes.get(3).getFeature().compareTo("pit")==0) {
                state = "buildTop";
                nextNode = edgeNodes.get(3);
            }
            else if(edgeNodes.get(1)!=null && edgeNodes.get(1).getFeature().compareTo("tunnel")==0 && edgeNodes.get(1).beenPresent(this)==false) {
                state = "moveBottom";
                nextNode = edgeNodes.get(1);
            }
            else if(edgeNodes.get(0)!=null && edgeNodes.get(0).getFeature().compareTo("tunnel")==0 && edgeNodes.get(0).beenPresent(this)==false) {
                state = "moveRight";
                nextNode = edgeNodes.get(0);
            }
            else if(edgeNodes.get(2)!=null && edgeNodes.get(2).getFeature().compareTo("tunnel")==0 && edgeNodes.get(2).beenPresent(this)==false) {
                state = "moveLeft";
                nextNode = edgeNodes.get(2);
            }
            else if(edgeNodes.get(3)!=null && edgeNodes.get(3).getFeature().compareTo("tunnel")==0 && edgeNodes.get(3).beenPresent(this)==false) {
                state = "moveTop";
                nextNode = edgeNodes.get(3);
            }
            else {
                state = "stay";
            }
            
            //Determine output/action
            switch(state){
                case "mine": 
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs gold!");
                    this.totalGoldMined+= currPos.digGold();
                    totalGold++;
                    break;
                case "die":
                    this.delete = true;
                    if(currPos==null){
                        diedByRiver++;
                        deathInt = 1;
                    }
                    else if(currPos.getFeature().compareTo("lava")==0){
                        diedByLava++;
                        deathInt = 2;
                    }
                    else if(currPos.getFeature().compareTo("pit")==0){
                        diedByPit++;
                        deathInt = 3;
                    }
                    
                    if(currPos!=null){
                        printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" falls into "+currPos.getFeature()+" and dies!");
                    }
                    else{
                       printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" flows off the map by River at "+currString+" and dies!"); 
                    }
                    break;
                case "digRight":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "digBottom":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "digLeft":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "digTop":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "buildRight":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "buildBottom":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "buildLeft":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "buildTop":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "moveRight":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+"("+this.getType()+")"+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;    
                case "moveBottom":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;
                case "moveLeft":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;
                case "moveTop":
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;
                default:
                    MapNode prevPos = prevLoc.pop();
                    printToWriter("Dwarf "+this.getID()+"("+this.getType()+")"+" treks back. Moves from current position "+currPos.toString()+" to previous position "+prevPos.toString()+".");
                    currPos = prevPos;
                    updatePos();
                    break;
            }
        }
        
        
        private void FiniteState0(){
            printToWriter("Dwarf "+this.getID()+" current position = "+currPos.toString());
            MapNode nextNode = null;
            //Determine state
            if(currPos.getFeature().compareTo("gold")==0) state = "mine";
            else if(currPos.getFeature().compareTo("water")==0||currPos.getFeature().compareTo("lava")==0||currPos.getFeature().compareTo("pit")==0) state = "die";
            else if(edgeNodes.get(0)!=null && edgeNodes.get(0).getFeature().compareTo("rock")==0) {
                state = "digRight";
                nextNode = edgeNodes.get(0);
            }
            else if(edgeNodes.get(1)!=null && edgeNodes.get(1).getFeature().compareTo("rock")==0) {
                state = "digBottom";
                nextNode = edgeNodes.get(1);
            }
            else if(edgeNodes.get(2)!=null && edgeNodes.get(2).getFeature().compareTo("rock")==0) {
                state = "digLeft";
                nextNode = edgeNodes.get(2);
            }
            else if(edgeNodes.get(3)!=null && edgeNodes.get(3).getFeature().compareTo("rock")==0) {
                state = "digTop";
                nextNode = edgeNodes.get(3);
            }
            else if(edgeNodes.get(0)!=null && edgeNodes.get(0).getFeature().compareTo("water")==0) {
                state = "buildRight";
                nextNode = edgeNodes.get(0);
            }
            else if(edgeNodes.get(1)!=null && edgeNodes.get(1).getFeature().compareTo("water")==0) {
                state = "buildBottom";
                nextNode = edgeNodes.get(1);
            }
            else if(edgeNodes.get(2)!=null && edgeNodes.get(2).getFeature().compareTo("water")==0) {
                state = "buildLeft";
                nextNode = edgeNodes.get(2);
            }
            else if(edgeNodes.get(3)!=null && edgeNodes.get(3).getFeature().compareTo("water")==0) {
                state = "buildTop";
                nextNode = edgeNodes.get(3);
            }
            else if(edgeNodes.get(1)!=null && edgeNodes.get(1).getFeature().compareTo("tunnel")==0 && edgeNodes.get(1).beenPresent(this)==false) {
                state = "moveBottom";
                nextNode = edgeNodes.get(1);
            }
            else if(edgeNodes.get(0)!=null && edgeNodes.get(0).getFeature().compareTo("tunnel")==0 && edgeNodes.get(0).beenPresent(this)==false) {
                state = "moveRight";
                nextNode = edgeNodes.get(0);
            }
            else if(edgeNodes.get(2)!=null && edgeNodes.get(2).getFeature().compareTo("tunnel")==0 && edgeNodes.get(2).beenPresent(this)==false) {
                state = "moveLeft";
                nextNode = edgeNodes.get(2);
            }
            else if(edgeNodes.get(3)!=null && edgeNodes.get(3).getFeature().compareTo("tunnel")==0 && edgeNodes.get(3).beenPresent(this)==false) {
                state = "moveTop";
                nextNode = edgeNodes.get(3);
            }
            else {
                state = "stay";
            }
            
            //Determine output/action
            switch(state){
                case "mine": 
                    printToWriter("Dwarf "+this.getID()+" digs gold!");
                    this.totalGoldMined+= currPos.digGold();
                    totalGold++;
                    break;
                case "die":
                    this.delete = true;
                    if(currPos.getFeature().compareTo("lava")==0){
                        diedByLava++;
                        deathInt = 1;
                    }
                    else if(currPos.getFeature().compareTo("pit")==0){
                        diedByPit++;
                        deathInt = 2;
                    }
                    else if(currPos.getFeature().compareTo("water")==0){
                        diedByRiver++;
                        deathInt = 3;
                    }
                    printToWriter("Dwarf "+this.getID()+" falls into "+currPos.getFeature()+" and dies!");
                    break;
                case "digRight":
                    printToWriter("Dwarf "+this.getID()+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "digBottom":
                    printToWriter("Dwarf "+this.getID()+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "digLeft":
                    printToWriter("Dwarf "+this.getID()+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "digTop":
                    printToWriter("Dwarf "+this.getID()+" digs through rock at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractDig(nextNode);
                    break;
                case "buildRight":
                    printToWriter("Dwarf "+this.getID()+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "buildBottom":
                    printToWriter("Dwarf "+this.getID()+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "buildLeft":
                    printToWriter("Dwarf "+this.getID()+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "buildTop":
                    printToWriter("Dwarf "+this.getID()+" builds a bridge over pit at "+nextNode.toString()+" and moves from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractBuild(nextNode);
                    break;
                case "moveRight":
                    printToWriter("Dwarf "+this.getID()+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;    
                case "moveBottom":
                    printToWriter("Dwarf "+this.getID()+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;
                case "moveLeft":
                    printToWriter("Dwarf "+this.getID()+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;
                case "moveTop":
                    printToWriter("Dwarf "+this.getID()+" moves into "+nextNode.getFeature()+" from "+currPos.toString()+" to "+nextNode.toString()+".");
                    dwarfNodeInteractMove(nextNode);
                    break;
                default:
                    MapNode prevPos = prevLoc.pop();
                    printToWriter("Dwarf "+this.getID()+" treks back. Moves from current position "+currPos.toString()+" to previous position "+prevPos.toString()+".");
                    currPos = prevPos;
                    updatePos();
                    break;
            }
        }
        
        private void dwarfNodeInteractMove(MapNode nextNode){
            currPos = nextNode;
            prevLoc.push(currPos);
            currPos.addDwarf(this);
            updatePos();
        }
        
        private void dwarfNodeInteractBuild(MapNode nextNode){
            currPos = nextNode;
            currPos.buildBridge();
            prevLoc.push(currPos);
            currPos.addDwarf(this);
            updatePos();
        }
        
        private void dwarfNodeInteractDig(MapNode nextNode){
            currPos = nextNode;
            currPos.dig();
            prevLoc.push(currPos);
            currPos.addDwarf(this);
            updatePos();
        }
        
        /**
         * Paints visualization of Dwarf object on canvas
         */
        public void paint(Graphics g) {
            g.setColor(dwarfColor);
            g.fillOval(vectorX-10,vectorY-10,20,20);
            g.setColor(color);
            g.fillOval(vectorX-5,vectorY-5,10,10);
            g.setColor(new Color(0,0,255));
            g.drawString(Integer.toString(this.getID()),vectorX-10, vectorY+10);
        }
    
        private void updatePos(){
            vectorX = 30*currPos.getX()+15;
            vectorY = 30*currPos.getY()+15;
        
            if(currPos.getY()>0){
                edgeNodes.set(3,map.get(currPos.getX(),currPos.getY()-1));//top
            }
            else edgeNodes.set(3,null);//top
        
            if(currPos.getX()>0){
                edgeNodes.set(2,map.get(currPos.getX()-1,currPos.getY()));//left
            }
            else edgeNodes.set(2,null);//left
        
            if(currPos.getX()<map.getWidth()-1){
                edgeNodes.set(0,map.get(currPos.getX()+1,currPos.getY()));//right
            }
            else edgeNodes.set(0,null);//right
        
            if(currPos.getY()<map.getHeight()-1){
                edgeNodes.set(1,map.get(currPos.getX(),currPos.getY()+1));//down
            }
            else edgeNodes.set(1,null);//down
        }
        
        /**
         * Returns the difference factor used to sort out Dwarf objects in a Queue 
         * 
         * @return difference factor of Dwarf object
         */
        public int getDiff(){
            return diff;
        }
        
        /**
         * Returns the ID of the Dwarf object
         * 
         * @return ID of the Dwarf object
         */
        public int getID(){
            return id;
        }
        
        /**
         * Sets the difference factor used to sort out Dwarf objects in a Queue 
         * 
         * @param difference factor of Dwarf object
         */
        public void setDiff(int value){
            diff = value;
        }
        
        /**
         * Returns true if Dwarf object has been terminated in the simulation
         * 
         * @return boolean value determining the existence of object in Simulation
         */
        public boolean isDeleted(){
            return delete;
        }
        
        /**
         * Returns the total amount of gold mined by the Dwarf object
         * 
         * @return amount of treasure carried by Dwarf object
         */
        public int getCarry(){
            return totalGoldMined;
        }
        
        /**
         * Returns the current postion of the Dwarf object
         * 
         * @return Position of the Dwarf object
         */
        public String getPos(){
            return currPos.toString();
        }
        
        /**
         * Returns the total data of Dwarf (Total number of Gold mined and way of death)
         * 
         * @return int array containing total number of gold mined and integer indicating way of death
         */
        public int[] getData(){
            int [] output = new int[2];
            output[0] = totalGoldMined;
            output[1] = deathInt;
            return output;
        }
        
        /**
         * Returns the type of Dwarf of the Dwarf object
         * 
         * @return String type of Dwarf
         */
        public String getType(){
            return type;
        }
        
        /**
         * Compares two Dwarf objects based on difference factor
         * Returns the current postion of the Dwarf object
         * @param Dwarf object to be compared to object
         * @return difference in the difference factor of the input Dwarf object
         */
        @Override
        public int compareTo(Dwarf object){
            return (int) (diff - object.getDiff());
        }
}
