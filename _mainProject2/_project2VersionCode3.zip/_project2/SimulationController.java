import java .awt  .Canvas;
import java .awt  .Graphics;
import java .awt  .Color;
import javax.swing.JFrame;
import java.util.concurrent.TimeUnit;
import java.util.*;
import java.io.*;
/**
 * Class that controls the game and simulation.
 *
 * @author Sena Yevenyo
 * @version October 21, 2019
 */
public class SimulationController extends Canvas
{
    // instance variables - replace the example below with your own
    public static int mapWidth;
    public static int mapHeight;
    private JFrame frame;
    private int squareSize = 25;
    private int gridSize = 30;
    private int parkSizeX, parkSizeY;
    private int numOfDwarfs = 20;
    private Map map;
    String logFilename = null;
    PrintWriter writer = null;
    File logData = null;
    /**
     * Main method of the program.
     * 
     * Runs a for loop simulating the GlobalClock.tick() in the final program.
     */
    public static void main(String args[]){
        String fileName = null;
        SimulationController simul = null;
        System.out.println(args[0]);
        System.out.println(args[1]);
        System.out.println(args[2]);
        // System.out.println(args[3])
        try{
            fileName = args[0]+".txt";
            simul = new SimulationController(fileName,Integer.parseInt(args[1]),Integer.parseInt(args[2]));
        }catch(Exception e){
            System.err.println(e);
        }
        
        simul.start();
    }

    /**
     * Constructor for objects of class SimulationController
     */
    public SimulationController(String filename)
    {
        // initialise instance variables
        logFilename = "log"+filename;
        frame = new JFrame("Gold mine");
        mapWidth = 30;
        mapHeight = 30;
        parkSizeX = mapWidth*gridSize;
        parkSizeY = mapHeight*gridSize;
        this.setSize(parkSizeX, parkSizeY+30);
        map = new Map(mapWidth,mapHeight);
        map.createRiver(1,1,10,"topDown");
        map.createRiver(28,28,10,"topDown");
        map.createLava(5,7);
        map.createLava(16,8);
        map.createLava(3,9);
        map.createLava(18,16);
        map.createLava(23,4);
        map.createLava(29,29);
        map.createPit(4,3);
        map.createPit(11,10);
        map.createPit(21,5);
        map.createPit(6,15);
        map.createPit(13,8);
        map.createGold(13,6);
        map.createGold(21,9);
        map.createGold(8,6);
        map.createGold(21,21);
        try{
            logData = new File(logFilename);
            writer = new PrintWriter(logData);
            Dwarf.setWriter(writer, null);
        }catch(Exception e){
            System.err.println(e);
        }

        Dwarf.setNumOfDwarfs(10,10,10,10,10);
        Dwarf.setMap(map);
        Dwarf.initDwarfs();

        frame.add(this);
        frame.setSize(parkSizeX,parkSizeY);
        frame.setVisible(true);
    }

    public SimulationController(String filename, int x, int y){
        logFilename = "log"+filename;
        frame = new JFrame("Gold mine");
        mapWidth = x;
        mapHeight = y;
        parkSizeX = mapWidth*gridSize;
        parkSizeY = mapHeight*gridSize;
        this.setSize(parkSizeX, parkSizeY);
        map = new Map(mapWidth,mapHeight);
        map.createRiver(1,1,10,"topDown");
        map.createRiver(28,28,10,"topDown");
        map.createLava(5,7);
        map.createLava(16,8);
        map.createLava(3,9);
        map.createLava(18,16);
        map.createLava(23,4);
        map.createLava(29,29);
        map.createPit(4,3);
        map.createPit(11,10);
        map.createPit(21,5);
        map.createPit(6,15);
        map.createPit(13,8);
        map.createGold(13,6);
        map.createGold(21,9);
        map.createGold(8,6);
        map.createGold(21,21);
        try{
            logData = new File(logFilename);
            writer = new PrintWriter(logData);
            Dwarf.setWriter(writer, null);
        }catch(Exception e){
            System.err.println(e);
        }

        Dwarf.setNumOfDwarfs(10,10,10,10,10);
        Dwarf.setMap(map);
        Dwarf.initDwarfs();

        frame.add(this);
        frame.setSize(parkSizeX,parkSizeY);
        frame.setVisible(true);
    }

    public void start(){
        writer.println("+++Starting simulation+++");
        writer.println("+++Dwarfs about to start!+++");
        writer.println();
        writer.println("===================================================");
        writer.println();
        while(GlobalClock.time()<3000){
            Dwarf.goDwarfs(this);
            try{
                TimeUnit.MILLISECONDS.sleep(100);
            }catch(InterruptedException e){
                System.out.println(e);
            }
            GlobalClock.tick();
        }

        writer.println();
        writer.println("Simulation completed");
        writer.println("===================================================");
        writer.println();
        System.out.println("Simulation completed");
        writer.close();
    }

    public void paint(Graphics g){
        map.paint(g);
        Dwarf.paintDwarfs(g);
    }
    
    public void update(Graphics g){
        map.paint(g);
        Dwarf.paintDwarfs(g);
    }
}
